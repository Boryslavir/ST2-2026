from graph import Graph
import tkinter as tk
import math
import time
import threading
from collections import defaultdict

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry('650x650')
        self.graph = graph
        self.canvas = tk.Canvas(self, width=600, height=600, bg='white')
        self.canvas.pack(pady=10)

        self.vertex_positions = {}
        self.node_radius = 20
        self.spacing = 180
        self.center = (300, 300)
        self.vertex_circles = {}
        self.edge_lines = {}

        control_frame = tk.Frame(self)
        control_frame.pack()

        tk.Button(control_frame, text="Run BFS", command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Run DFS", command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Undirected Cycle", command=self.run_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Directed Cycle", command=self.run_directed_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Reset Colors", command=self.reset_colors).pack(side=tk.LEFT, padx=5)

        self.info_label = tk.Label(self, text="Graph Loaded. Select an algorithm.")
        self.info_label.pack(pady=5)

        self.draw_graph()


    def draw_graph(self):
        self.canvas.delete("all")

        all_nodes = set(self.graph.graph.keys())
        for neighbors in self.graph.graph.values():
            all_nodes.update(neighbors)
        vertices = sorted(list(all_nodes))

        n = len(vertices)
        if n == 0: return

        angle_gap = 360 / n
        cx, cy = self.center

        for i, v in enumerate(vertices):
            angle = i * angle_gap
            x = cx + self.spacing * math.cos(math.radians(angle))
            y = cy + self.spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            circle_id = self.canvas.create_oval(
                x - self.node_radius,
                y - self.node_radius,
                x + self.node_radius,
                y + self.node_radius,
                fill='lightblue',
                outline='black',
                width=2
            )
            self.vertex_circles[v] = circle_id
            self.canvas.create_text(x, y, text=v, font=("Arial", 12, "bold"))

        # Drawing edges using the validated positions
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                dx, dy = x2 - x1, y2 - y1
                dist = math.sqrt(dx*dx + dy*dy)
                if dist == 0: continue
                ox, oy = dx/dist * self.node_radius, dy/dist * self.node_radius

                if self.graph.directed:
                    line_id = self.canvas.create_line(x1+ox, y1+oy, x2-ox, y2-oy, arrow=tk.LAST, width=2)
                else:
                    pair = tuple(sorted((v, nbr)))
                    if pair in self.edge_lines: continue 
                    line_id = self.canvas.create_line(x1+ox, y1+oy, x2-ox, y2-oy, width=2)

                self.edge_lines[(v, nbr)] = line_id


    def reset_colors(self):
        for circle_id in self.vertex_circles.values():
            self.canvas.itemconfig(circle_id, fill='lightblue')
        for edge_id in self.edge_lines.values():
            self.canvas.itemconfig(edge_id, fill='black', width=2)
        self.info_label.config(text="Colors reset.")


    def highlight_vertex(self, vertex, color):
        cid = self.vertex_circles.get(vertex)
        if cid: self.canvas.itemconfig(cid, fill=color)


    def highlight_edge(self, v1, v2, color):
        eid = self.edge_lines.get((v1, v2)) or self.edge_lines.get((v2, v1))
        if eid: self.canvas.itemconfig(eid, fill=color, width=3)


    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            visited = set()
            # Start with the first alphabetical node available
            nodes = sorted(list(self.vertex_positions.keys()))
            if not nodes: return
            start_node = nodes[0]

            stack_or_queue = [start_node]
            self.info_label.config(text=f"Running {method.upper()}...")

            while stack_or_queue:
                vertex = stack_or_queue.pop(0) if method == "bfs" else stack_or_queue.pop()
                if vertex not in visited:
                    self.highlight_vertex(vertex, 'orange' if method == "bfs" else 'purple')
                    visited.add(vertex)
                    time.sleep(0.6)
                    # Use .get() to handle sink nodes safely
                    for nbr in self.graph.graph.get(vertex, []):
                        if nbr not in visited:
                            stack_or_queue.append(nbr)
                            self.highlight_edge(vertex, nbr, 'green' if method == "bfs" else 'blue')
                            time.sleep(0.2)
            self.info_label.config(text=f"{method.upper()} complete.")

        threading.Thread(target=worker, daemon=True).start()


    def run_cycle_detection(self):
        if self.graph.directed:
            self.info_label.config(text="Use 'Detect Directed Cycle' for this graph.")
            return

        def worker():
            self.reset_colors()
            visited = set()
            self.info_label.config(text="Detecting cycle (Undirected)...")

            def dfs(curr, prev):
                visited.add(curr)
                self.highlight_vertex(curr, 'yellow')
                time.sleep(0.5)

                for nbr in self.graph.graph.get(curr, []):
                    if nbr == prev: continue
                    if nbr in visited:
                        self.highlight_edge(curr, nbr, 'red')
                        self.highlight_vertex(nbr, 'red')
                        self.highlight_vertex(curr, 'red')
                        return True
                    self.highlight_edge(curr, nbr, 'orange')
                    if dfs(nbr, curr): return True
                return False

            found = False
            for node in list(self.vertex_positions.keys()):
                if node not in visited:
                    if dfs(node, None):
                        found = True
                        break

            msg = "Cycle detected!" if found else "No cycles found."
            self.info_label.config(text=msg)

        threading.Thread(target=worker, daemon=True).start()


    def run_directed_cycle_detection(self):
        if not self.graph.directed:
            self.info_label.config(text="Use 'Detect Undirected Cycle' for this graph.")
            return

        def worker():
            self.reset_colors()
            visited = set()
            rec_stack = set()
            self.info_label.config(text="Detecting cycle (Directed)...")

            def dfs(v):
                visited.add(v)
                rec_stack.add(v)
                self.highlight_vertex(v, 'yellow')
                time.sleep(0.5)

                for nbr in self.graph.graph.get(v, []):
                    if nbr in rec_stack:
                        self.highlight_edge(v, nbr, 'red')
                        self.highlight_vertex(nbr, 'red')
                        self.highlight_vertex(v, 'red')
                        return True
                    if nbr not in visited:
                        self.highlight_edge(v, nbr, 'orange')
                        if dfs(nbr): return True

                rec_stack.remove(v)
                return False

            found = False
            for node in list(self.vertex_positions.keys()):
                if node not in visited:
                    if dfs(node):
                        found = True
                        break

            msg = "Directed Cycle detected!" if found else "No directed cycles."
            self.info_label.config(text=msg)

        threading.Thread(target=worker, daemon=True).start()


if __name__ == "__main__":
    class Graph:
        def __init__(self, directed=False):
            self.graph = defaultdict(list)
            self.directed = directed
        def add_edge(self, u, v):
            self.graph[u].append(v)
            if not self.directed: self.graph[v].append(u)

    # TEST CASE 1: Undirected Cycle (A-B-C-A)
    print("Running Undirected Graph Test...")
    g = Graph(directed=False)
    for edge in [('A','B'), ('B','C'), ('C', 'A'), ('C','D')]:
        g.add_edge(*edge)

    # TEST CASE 2: Directed Cycle (A->B->C->A) + Sink Node (D)
    # print("Running Directed Graph Test...")
    # g = Graph(directed=True)
    # for edge in [('A','B'), ('B','C'), ('C','A'), ('C','D')]:
    #     g.add_edge(*edge)

    app = GraphVisualizer(g)
    app.mainloop()
