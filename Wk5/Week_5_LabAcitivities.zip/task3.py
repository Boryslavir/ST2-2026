# --- TASK 3: TOWER OF HANOI ---


moves_count = 0 # Global variable 

def moveDisks(n, fromTower, toTower, auxTower):
    global moves_count
    if n == 1:
        # print(f"Move disk {n} from {fromTower} to {toTower}") # Optional: keep for small n
        moves_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        # print(f"Move disk {n} from {fromTower} to {toTower}")
        moves_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

def main():
    global moves_count
    n = int(input("Enter number of disks: "))
    moves_count = 0
    moveDisks(n, 'A', 'B', 'C')
    print("The moves are:")
    print(f"Number of moves is {moves_count}")

if __name__ == "__main__":
    main()
