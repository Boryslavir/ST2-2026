from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")
        self.width, self.height = 400, 400
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()
        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, width=5).pack(side=LEFT)
        Button(frame1, text="Display", command=self.display).pack(side=LEFT)
        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        order = int(self.order.get())
        # Starting triangle points for the snowflake
        p1 = [200, 20]
        p2 = [20, 320]
        p3 = [380, 320]
        self.draw_koch_edge(order, p1, p2)
        self.draw_koch_edge(order, p2, p3)
        self.draw_koch_edge(order, p3, p1)

    def draw_koch_edge(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            # 1. Calculate the 1/3 and 2/3 points
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            pa = [p1[0] + dx/3, p1[1] + dy/3]
            pc = [p1[0] + 2*dx/3, p1[1] + 2*dy/3]

            # 2. Calculate the peak (pb) of the outward triangle 
            # Using 60-degree rotation math
            angle = math.radians(-60)
            nx = (pa[0] - pc[0]) * math.cos(angle) - (pa[1] - pc[1]) * math.sin(angle) + pc[0]
            ny = (pa[0] - pc[0]) * math.sin(angle) + (pa[1] - pc[1]) * math.cos(angle) + pc[1]
            pb = [nx, ny]

            # 3. Recursively draw the 4 new segments [cite: 186]
            self.draw_koch_edge(order - 1, p1, pa)
            self.draw_koch_edge(order - 1, pa, pb)
            self.draw_koch_edge(order - 1, pb, pc)
            self.draw_koch_edge(order - 1, pc, p2)

# Run the application
if __name__ == "__main__":
    KochSnowflake()
