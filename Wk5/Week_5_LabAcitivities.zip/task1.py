# --- TASK 1: RECURSION VS ITERATION ---


# Basic - Recursive (Original)
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Basic - Iterative (Converted)
def sum_iterative(n):
    result = 0
    for i in range(1, n + 1):
        result += i
    return result


# Factorial - Recursive (Original)
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Factorial - Iterative (Converted)
def factorial_iterative(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


# Fibonacci - Recursive (Original)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Fibonacci - Iterative (Converted)
def fibonacci_iterative(n):
    if n <= 0: return 0
    if n == 1: return 1
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


# Comparison Example
n = 20
print(f"Recursive Basic({n}): {sum_of_natural_numbers(n)}")
print(f"Iterative Basic({n}): {sum_iterative(n)}")
print(f"Recursive Factorial({n}): {factorial(n)}")
print(f"Iterative Factorial({n}): {factorial_iterative(n)}")
print(f"Recursive Fibonacci({n}): {fibonacci(n)}")
print(f"Iterative Fibonacci({n}): {factorial_iterative(n)}")

n = 5
print(f"Recursive Basic({n}): {sum_of_natural_numbers(n)}")
print(f"Iterative Basic({n}): {sum_iterative(n)}")
print(f"Recursive Factorial({n}): {factorial(n)}")
print(f"Iterative Factorial({n}): {factorial_iterative(n)}")
print(f"Recursive Fibonacci({n}): {fibonacci(n)}")
print(f"Iterative Fibonacci({n}): {factorial_iterative(n)}")
