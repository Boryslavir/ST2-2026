import tkinter as tk

class SierpinskiTriangle:
    def __init__(self):
        # --- GUI Setup ---
        window = tk.Tk()
        window.title("Task 4a: Sierpinski Triangle")

        # Increased size for better report screenshots
        self.width = 400
        self.height = 400
        self.canvas = tk.Canvas(window, width=self.width, height=self.height, bg="white")
        self.canvas.pack(pady=10)

        # Control Frame
        frame1 = tk.Frame(window)
        frame1.pack(padx=10, pady=10)

        tk.Label(frame1, text="Enter an order: ").pack(side=tk.LEFT)
        self.order = tk.StringVar()
        self.entry = tk.Entry(frame1, textvariable=self.order, width=5, justify=tk.RIGHT)
        self.entry.pack(side=tk.LEFT, padx=5)

        tk.Button(frame1, text="Display Sierpinski Triangle", 
                  command=self.display).pack(side=tk.LEFT)

        window.mainloop()

    def display(self):
        """Clears the canvas and starts the recursive drawing."""
        self.canvas.delete("line")
        try:
            order = int(self.order.get())
            # Define the three vertices of the main triangle
            p1 = [self.width / 2, 20]
            p2 = [20, self.height - 20]
            p3 = [self.width - 20, self.height - 20]

            self.displayTriangles(order, p1, p2, p3)
        except ValueError:
            print("Please enter a valid integer for the order.")

    def displayTriangles(self, order, p1, p2, p3):
        """Recursive function to draw triangles."""
        if order == 0:
            # Base Case: Draw the actual lines of the triangle
            self.draw_line(p1, p2)
            self.draw_line(p2, p3)
            self.draw_line(p3, p1)
        else:
            # Recursive Case: Get midpoints to create 3 smaller triangles
            p12 = self.get_midpoint(p1, p2)
            p23 = self.get_midpoint(p2, p3)
            p31 = self.get_midpoint(p3, p1)

            # Call recursion for the three corner triangles
            self.displayTriangles(order - 1, p1, p12, p31)
            self.displayTriangles(order - 1, p12, p2, p23)
            self.displayTriangles(order - 1, p31, p23, p3)

    def draw_line(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line", fill="blue")

    def get_midpoint(self, p1, p2):
        return [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]

# Run the application
if __name__ == "__main__":
    SierpinskiTriangle()
